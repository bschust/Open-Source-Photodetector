import csv

from youngblood_photodetector import SampleData, UNIT_REGISTRY

# pint's stringified units are a bit too verbose for our tastes
# this dict contains the relevant units for our daq tool
# written in an abbreviated form
STRINGIFIED_UNITS = {
    UNIT_REGISTRY.us : 'us',
    UNIT_REGISTRY.ms : 'ms',
    UNIT_REGISTRY.s : 's',
    UNIT_REGISTRY.pwatt : 'pW',
    UNIT_REGISTRY.nwatt : 'nW',
    UNIT_REGISTRY.uwatt : 'uW',
    UNIT_REGISTRY.mwatt : 'mW',
    UNIT_REGISTRY.watt : 'W'
}

def get_sample_subrange(sample_data, start_time, end_time):
    return [(time,intensity) for time,intensity in sample_data if (time >= start_time and time <= end_time)]

def export_samples_csv(filepath, sample_data, start_time, end_time, time_unit=UNIT_REGISTRY.secs, intensity_unit=UNIT_REGISTRY.watt):
    """
    Writes the sample data to a CSV at the specified filepath using the specified units for time and intensity
    """
    with open(filepath, 'w', newline='') as csvfile:
        # Format column names based on supplied units for time / intensity
        TIME_NAME = 'Sample Time ({0})'.format(STRINGIFIED_UNITS[time_unit])
        INTENSITY_NAME = 'Intensity ({0})'.format(STRINGIFIED_UNITS[intensity_unit])

        fieldnames = [TIME_NAME, INTENSITY_NAME]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        samples_to_write = get_sample_subrange(sample_data, start_time, end_time)

        writer.writeheader()
        for time,intensity in samples_to_write:
            writer.writerow({TIME_NAME: time.to(time_unit).magnitude, INTENSITY_NAME: intensity.to(intensity_unit).magnitude})

def get_local_maximum(sample_data, start_time, end_time):
    """
    Finds the sample with the maximum intensity over the specified interval
    """
    local_samples = get_sample_subrange(sample_data, start_time, end_time)
    if len(local_samples) == 0:
        return None
    else:
        local_max = local_samples[0]
        for sample in local_samples:
            if sample[1] > local_max[1]:
                local_max = sample
        return local_max