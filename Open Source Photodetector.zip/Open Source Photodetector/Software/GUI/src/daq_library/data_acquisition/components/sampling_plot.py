import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
from serial.tools.list_ports import comports
from youngblood_photodetector import UNIT_REGISTRY as ureg

import data_acquisition.app
import data_acquisition.components.gain_select
import data_acquisition.components.wavelength_input
from ..daq_utils import STRINGIFIED_UNITS


TIME_UNITS = (ureg.s, ureg.ms, ureg.us)
INTENSITY_UNITS = (ureg.watt, ureg.mwatt, ureg.uwatt, ureg.nwatt, ureg.pwatt)

REFRESH_RATE = 5
UPDATE_INTERVAL_MS = 1000//REFRESH_RATE
STOPPED_INTERVAL_MS = 3600000

layout = html.Div(children=[
    html.Div(
        children=[
            data_acquisition.components.wavelength_input.layout,
            data_acquisition.components.gain_select.layout
        ],
        style={'display': 'flex'}
    ),

    

    html.Div(
        id='sampling-plot-real-time-options',
        children=[
            html.H3('Real-time Sampling'),
            html.Div(
                children=[
                    'Sampling frequency:',
                    dcc.Input(
                        id='sampling-plot-real-time-frequency-value',
                        type='number',
                        placeholder=''
                    ),
                    html.Div(
                        'per',
                        style={'margin':'5px'}
                    ),
                    dcc.Dropdown(
                        id='sampling-plot-real-time-frequency-units',
                        options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in TIME_UNITS],
                        value='s',
                        style={'width':'100px'},
                    )
                ],
                style={'display':'flex'}
            ),
            html.Button("Start/Resume Sampling", id='start-sampling', disabled=True, n_clicks_timestamp=0,style={'margin-top':'15px'}),
            html.Button("Pause Sampling", id='stop-sampling', disabled=True, n_clicks_timestamp=0),    
        ],
        style={'margin-top':'15px'}
    ),
    html.Div(
        id='sampling-plot-precision-options',
        children=[
            html.H3('Precision Sampling'),
            html.Div(
                children=[
                    'Sampling frequency:',
                    dcc.Input(
                        id='sampling-plot-precision-frequency-value',
                        type='number',
                        placeholder=''
                    ),
                    html.Div(
                        'per',
                        style={'margin':'5px'}
                    ),
                    dcc.Dropdown(
                        id='sampling-plot-precision-frequency-units',
                        options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in TIME_UNITS],
                        value='s',
                        style={'width':'100px'},
                    )
                ],
                style={'display':'flex','margin-top':'15px'}
            ),
            html.Div(
                children=[
                    'Sampling period:',
                    dcc.Input(
                        id='sampling-plot-precision-period-value',
                        type='number',
                        placeholder=''
                    ),
                    dcc.Dropdown(
                        id='sampling-plot-precision-period-units',
                        options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in TIME_UNITS],
                        value='s',
                        style={'width':'100px'},
                    )
                ],
                style={'display':'flex','margin-top':'15px'}
            ),
            html.Button('Sample',id='precision-sample',n_clicks_timestamp=0,style={'margin-top':'15px'})
        ],
        style={'margin-top':'15px'}
    ),

    html.Button("Reset Samples", id='reset-sampling', disabled=True, n_clicks_timestamp=0,style={'margin-top':'15px'}),

    html.Div(children=[
        dcc.Interval(
            id='sampling-interval',
            interval=STOPPED_INTERVAL_MS,
            n_intervals=0
        ),
        dcc.Graph(
            id='sample-plot',
            figure={
                'data' : [
                    {'x': [], 'y': [], 'type': 'scatter'}
                ],
                'layout' : {
                    'title': 'Plotted Samples',
                    'yaxis': {
                        'range': [],
                        'title': 'Intensity (W)'
                    },
                    'xaxis': {
                        'range': [],
                        'title': 'Time (s)'
                    }
                }
            },
            style={'height': '450px'}
        ),
    ]),

    html.Div(
        children=[
            html.Div(
                'Time Unit:',
                style={'margin': '5px'}
            ),
            dcc.Dropdown(
                id='sample-plot-time-unit',
                options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in TIME_UNITS],
                value='s',
                style={'width':'100px'},
            ),
            html.Div(
                'Intensity Unit:',
                style={'margin': '5px'}
            ),
            dcc.Dropdown(
                id='sample-plot-intensity-unit',
                options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in INTENSITY_UNITS],
                value='nW',
                style={'width':'100px'},
            ),
        ],
        style={'display':'flex', 'margin-top': '15px'}
    ),
])

@data_acquisition.app.app.callback(
    [Output('start-sampling','disabled'),
    Output('stop-sampling','disabled'),
    Output('reset-sampling','disabled')],
    [Input('device-status','children')]
)
def enable_sampling_buttons(device_status):
    """
    Allow the sampling control buttons to be clicked only when a device is connected.
    """
    if data_acquisition.app.device is not None:
        return False,False,False
    else:
        return True,True,True

@data_acquisition.app.app.callback(
    Output('sampling-interval','interval'),
    [Input('start-sampling','n_clicks_timestamp'),
    Input('stop-sampling','n_clicks_timestamp'),
    Input('reset-sampling','n_clicks_timestamp')],
    [State('sampling-interval','interval'),
    State('sampling-plot-real-time-frequency-value','value'),
    State('sampling-plot-real-time-frequency-units','value')]
)
def control_sampling_interval(start_clicked,stop_clicked,reset_clicked,current_interval,frequncy_value,frequency_units):
    # if the start sampling button was most recently clicked, start sampling and set update interval to defined value
    if start_clicked > stop_clicked and start_clicked > reset_clicked:
        if data_acquisition.app.device is not None:
            sampling_frequency = frequncy_value / ureg.parse_units(frequency_units)
            data_acquisition.app.device.set_sampling_frequency(sampling_frequency)
            data_acquisition.app.device.start_sampling()
        return UPDATE_INTERVAL_MS

    # if the stop sampling button was most recently clicked, stop sampling
    # since the disabled property doesn't work in dash, we just set the interval not to update for an hour
    # (this may have to be adjusted if the app is meant to stay open for a long time)
    elif stop_clicked > start_clicked and stop_clicked > reset_clicked:
        if data_acquisition.app.device is not None:
            data_acquisition.app.device.stop_sampling()
        return STOPPED_INTERVAL_MS

    # otherwise, we clicked the reset samples button, which should clear samples on device
    # and keep whatever sampling/paused state was already occurring when this button was clicked
    else:
        if data_acquisition.app.device is not None:
            data_acquisition.app.device.clear_samples()
        return current_interval

@data_acquisition.app.app.callback(
    Output('sample-plot','figure'),
    [Input('sampling-interval','n_intervals'),
    Input('sample-plot-time-unit','value'),
    Input('sample-plot-intensity-unit','value'),
    Input('precision-sample','n_clicks_timestamp')],
    [State('sample-plot','figure'),
    State('start-sampling','n_clicks_timestamp'),
    State('stop-sampling','n_clicks_timestamp'),
    State('sampling-plot-precision-frequency-value','value'),
    State('sampling-plot-precision-frequency-units','value'),
    State('sampling-plot-precision-period-value','value'),
    State('sampling-plot-precision-period-units','value')]
)
def refresh_samples(
    n_intervals,
    time_unit,
    intensity_unit,
    precision_start_clicked,
    figure,
    realtime_start_clicked,
    realtime_stop_clicked,
    precision_frequency_value,
    precision_frequency_units,
    precision_period_value,
    precision_period_units
):
    time = []
    intensity = []
    if data_acquisition.app.device is not None:
        # no real-time sampling is occurring; just show whatever data is on the device
        if realtime_stop_clicked > realtime_start_clicked and realtime_stop_clicked > precision_start_clicked:
            sample_data = data_acquisition.app.device.current_samples.asdict()
            time = [data.to(ureg.parse_units(time_unit)).magnitude for data in sample_data['time']]
            intensity = [data.to(ureg.parse_units(intensity_unit)).magnitude for data in sample_data['intensity']]

        # real-time sampling is occurring
        elif realtime_start_clicked > precision_start_clicked:
            sample_data = data_acquisition.app.device.current_samples.asdict()
            # since Photodetector returns samples as pint measurements,
            # we need to send only the magnitudes of the measurements to the graph
            if data_acquisition.app.device.is_sampling():
                sub_time = sample_data['time'][-100:]
                sub_intensity = sample_data['intensity'][-100:]
                time = [data.to(ureg.parse_units(time_unit)).magnitude for data in sub_time]
                intensity = [data.to(ureg.parse_units(intensity_unit)).magnitude for data in sub_intensity]
            else:
                time = [data.to(ureg.parse_units(time_unit)).magnitude for data in sample_data['time']]
                intensity = [data.to(ureg.parse_units(intensity_unit)).magnitude for data in sample_data['intensity']]
            
            
        # precision sampling is happened, initiate precision sampling and 
        elif precision_start_clicked > realtime_start_clicked:
            precision_frequency_measurement = (precision_frequency_value / ureg.parse_units(precision_frequency_units)).to(1 / ureg.s)
            precision_period_measurement = (precision_period_value * ureg.parse_units(precision_period_units)).to(ureg.s)
            n_samples = int(precision_frequency_measurement.magnitude * precision_period_measurement.magnitude)

            data_acquisition.app.device.set_sampling_frequency(precision_frequency_measurement)

            sample_data = data_acquisition.app.device.sample_n_times(n_samples).asdict()

            time = [data.to(ureg.parse_units(time_unit)).magnitude for data in sample_data['time']]
            intensity = [data.to(ureg.parse_units(intensity_unit)).magnitude for data in sample_data['intensity']]


    figure['data'][0]['x'] = time
    figure['data'][0]['y'] = intensity

    if len(time) > 0:
        figure['layout']['xaxis']['range'] = [
            time[0],
            time[-1]
        ]

    figure['layout']['xaxis']['title'] = "Time ({0})".format(time_unit)
    figure['layout']['yaxis']['title'] = "Intensity ({0})".format(intensity_unit)
    return figure
