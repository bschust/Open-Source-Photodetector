import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import os
from youngblood_photodetector import UNIT_REGISTRY as ureg

import data_acquisition.app
from ..daq_utils import export_samples_csv, STRINGIFIED_UNITS

TIME_UNITS = (ureg.s, ureg.ms, ureg.us)
INTENSITY_UNITS = (ureg.watt, ureg.mwatt, ureg.uwatt, ureg.nwatt, ureg.pwatt)

layout = html.Div(
    id='export-csv-menu',
    children=[
        html.H2('Export to CSV'),
        dcc.ConfirmDialog(
            id='export-csv-confirmation',
            message='Export completed',
            displayed=False
        ),
        # filepath input
        html.Div(children=[
            'Save path:\t',
            dcc.Input(
                id='export-csv-path',
                type='text',
                placeholder=''
            ),
            html.Span(
                children='',
                id='export-csv-path-warning'
            )
        ]),

        # time interval select
        html.Div(
            children=[
                'Time Interval:\t',
                dcc.Input(
                    id='export-csv-start-interval-value',
                    type='number',
                    placeholder='',
                    style={'height': '25px', 'width': '50px'}
                ),
                dcc.Dropdown(
                    id='export-csv-start-interval-units',
                    options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in TIME_UNITS],
                    value=STRINGIFIED_UNITS[ureg.s],
                    style={'height': '15px', 'width': '50px'}
                ),
                html.Div(
                    'to',
                    style={'margin': '5px'}
                ),
                dcc.Input(
                    id='export-csv-end-interval-value',
                    type='number',
                    placeholder='',
                    style={'height': '25px', 'width': '50px'}
                ),
                dcc.Dropdown(
                    id='export-csv-end-interval-units',
                    options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in TIME_UNITS],
                    value=STRINGIFIED_UNITS[ureg.s],
                    style={'height': '15px', 'width': '50px'}
                )
            ],
            style={'display':'flex', 'margin-top':'15px','margin-bottom':'15px'}
        ),

        # output time unit select
        html.Div(
            children=[
                html.Div(
                    children=[
                        'Time Units:\t',
                        dcc.Dropdown(
                            id='export-csv-time-units',
                            options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in TIME_UNITS],
                            value='s',
                        )
                    ],
                    style={'width':'100px'}
                ),

                # output intensity unit select
                html.Div(
                    children=[
                        'Intensity Units:\t',
                        dcc.Dropdown(
                            id='export-csv-intensity-units',
                            options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in INTENSITY_UNITS],
                            value='nW'
                        )
                    ],
                    style={'width':'100px'}
                )
            ],
            style={'display':'flex','margin-top':'15px'}
        ),

        # Confirmation Button
        html.Button(
            'OK',
            id='export-csv-confirm',
            n_clicks_timestamp=0
        ),

        # Cancel Button
        html.Button(
            'Cancel',
            id='export-csv-cancel',
            n_clicks_timestamp=0
        ),
    ]
)

@data_acquisition.app.app.callback(
    Output('export-csv-path-warning','children'),
    [Input('export-csv-path','value')]
)
def check_valid_filepath(filepath):
    if filepath == '':
        return ''

    save_dir = os.path.dirname(filepath)
    if not os.path.exists(save_dir):
        return 'You must specify an existing save path'
    elif not os.path.isabs(save_dir):
        return 'You must specify an absolute save path'
    elif os.path.isdir(filepath):
        return 'You cannot save over a directory name'
    else:
        return ''

@data_acquisition.app.app.callback(
    [Output('export-csv-menu','style'),
    Output('export-csv-confirmation','displayed'),
    Output('export-csv-confirmation','message')],
    [Input('export-csv-confirm','n_clicks_timestamp'),
    Input('export-csv-cancel','n_clicks_timestamp')],
    [State('export-csv-menu','style'),
    State('export-csv-path','value'),
    State('export-csv-start-interval-value','value'),
    State('export-csv-start-interval-units', 'value'),
    State('export-csv-end-interval-value', 'value'),
    State('export-csv-end-interval-units', 'value'),
    State('export-csv-time-units','value'),
    State('export-csv-intensity-units','value')]
)
def complete_export(
    confirm_clicked,
    cancel_clicked,
    style,
    filepath,
    start_time_value,
    start_time_units,
    end_time_value,
    end_time_units,
    export_time_units,
    export_intensity_units
):
    result_message = 'CSV export successful!'
    show_confirmation = False
    
    # if neither button was actually clicked and we're firing off the event during initialization,
    # don't actually modify anything
    if confirm_clicked == 0 and cancel_clicked == 0:
        return style,show_confirmation,result_message

    # if the confirm button was clicked, export the csv
    if confirm_clicked > cancel_clicked and data_acquisition.app.device is not None:
        show_confirmation = True

        start_time_measurement = start_time_value * ureg.parse_units(start_time_units)
        end_time_measurement = end_time_value * ureg.parse_units(end_time_units)

        # export the csv
        try:
            export_samples_csv(
                filepath,
                data_acquisition.app.device.current_samples,
                start_time_measurement,
                end_time_measurement,
                time_unit=ureg.parse_units(export_time_units),
                intensity_unit=ureg.parse_units(export_intensity_units)
            )
        except Exception as e:
            result_message = str(e)

    # since either button results in closing the window, close it at the end (i.e. make it hidden)
    #style['display'] = 'hidden'
    return style,show_confirmation,result_message