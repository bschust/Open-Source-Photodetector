import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
from serial.tools.list_ports import comports
from youngblood_photodetector import device_is_photodetector,Photodetector

import data_acquisition.app

layout = html.Div(
    children=[
        'Gain:',
        dcc.Dropdown(
            id='gain-select',
            options=[],
            style={'width':'100px'},
            value='1'
        )
    ],
    style={'display': 'flex'}
)

@data_acquisition.app.app.callback(
    Output('gain-select','options'),
    [Input('device-status','children')]
)
def populate_gain_settings(device_status):
    if data_acquisition.app.device is not None and data_acquisition.app.device.gain_config is not None:
        return [{'label': setting[0], 'value': setting[0]} for setting in sorted(data_acquisition.app.device.gain_config, key=lambda x: int(x[0]))]
    else:
        return []

@data_acquisition.app.app.callback(
    Output('hidden-div','children'),
    [Input('gain-select','value')]
)
def select_gain(gain_setting):
    if data_acquisition.app.device is not None:
        data_acquisition.app.device.set_gain_setting(gain_setting)
    return None
