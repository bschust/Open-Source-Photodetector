import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
from decimal import Decimal
from serial.tools.list_ports import comports
from youngblood_photodetector import device_is_photodetector,Photodetector,UNIT_REGISTRY

import data_acquisition.app

layout = html.Div(children=[
    dcc.ConfirmDialog(
        id='invalid-wavelength-warning',
        message='Invalid wavelength entered, device value was not changed',
        displayed=False
    ),
    "Input Wavelength (nm):\t",
    dcc.Input(
        id='wavelength-input',
        placeholder="Enter a value...",
        type="number",
        value=1500
    ),
    html.Button("Update",id='update-input-wavelength')
])

@data_acquisition.app.app.callback(
    [Output('invalid-wavelength-warning','displayed'),
    Output('invalid-wavelength-warning','message')],
    [Input('update-input-wavelength','n_clicks')],
    [State('wavelength-input','value')]
)
def set_input_wavelength(n,wavelength):
    if data_acquisition.app.device is not None:
        try:
            wavelength_measurement = Decimal(wavelength) * UNIT_REGISTRY.nm
            data_acquisition.app.device.set_input_wavelength(wavelength_measurement)
        except ValueError as e:
            return True,str(e)
    return False,''