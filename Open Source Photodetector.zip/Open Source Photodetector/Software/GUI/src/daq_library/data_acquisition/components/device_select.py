import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
from serial.tools.list_ports import comports
from youngblood_photodetector import device_is_photodetector,Photodetector

import data_acquisition.app

layout = html.Div(children=[
    'Serial port:\t',
    dcc.Dropdown(
        id='comport-select',
        options=[],
        style={'width':'100px'},
        value=None
    ),
    html.Button("Refresh Devices", id='refresh-devices'),
    html.Div(children=[
        "Status: ",
        html.Span(
            id="device-status",
            children='Disconnected'
        )
    ])
])

@data_acquisition.app.app.callback(
    Output(component_id='comport-select',component_property='options'),
    [Input(component_id='refresh-devices',component_property='n_clicks')]
)
def update_comports(n):
    """
    When the "Refresh Devices" button is clicked, check all free serial ports
    and populate the serial port select dropdown with all free photodetectors
    """
    return [{"label": port.device, "value": port.device} for port in comports() if device_is_photodetector(port.device)]

@data_acquisition.app.app.callback(
    Output('device-status','children'),
    [Input('comport-select','value')]
)
def select_photodetector(com_port):
    """
    When a COM port is selected, attempt to initialize a photodetector connection at that port.
    If the current COM port selection is cleared, close the current connection if it exists.
    """
    if com_port != None:
        try:
            data_acquisition.app.device = Photodetector(com_port)
            return "Connected"
        except:
            data_acquisition.app.device = None
            return "Failed to connect"
    else:
        if data_acquisition.app.device != None:
            data_acquisition.app.device.close()
        data_acquisition.app.device = None
        return "No device selected"