import dash

device = None
app = dash.Dash(__name__)
app.config.suppress_callback_exceptions = True