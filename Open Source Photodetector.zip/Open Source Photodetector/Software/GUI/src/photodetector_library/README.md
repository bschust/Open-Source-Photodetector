# Youngblood Photodetector

This package contains code for interfacing with the photodetector device designed for the University of Pittsburgh's Youngblood Photonics Lab.

The photodetector was designed as part of a Spring 2020 Senior Design course.