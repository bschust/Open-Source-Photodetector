import csv
import os
import serial
import threading
import time

from decimal import Decimal

import pint

# pint unit registry used by the photodetector library
# this must be imported and used by other apps which wish to perform further computations on photodetector data
UNIT_REGISTRY = pint.UnitRegistry()

# device ID which will be used to verify connected serial device is the photodetector
DEVICE_ID = "Youngblood Photodetector"

# photodetector will send 16-bit voltage values from the on-board ADC
ADC_PRECISION_BITS = 16

# photovoltage values sent from the device are 16 bits
VOLTAGE_VALUE_BYTES = ADC_PRECISION_BITS//8

# baud rate for device
# TODO: adjust to baud rate of Teensy board when Teensy integration occurs
BAUD_RATE = 9600

# Sampling frequency for device
# TODO: update to match sampling frequency of final device; 400 only for checkoff #2
# SAMPLES_PER_SEC = Decimal(400) / UNIT_REGISTRY.secs

# Sampling period for device (equal to 1/frequency)
# SAMPLING_PERIOD = (Decimal(1) / SAMPLES_PER_SEC)


__resources_path = os.path.dirname(os.path.realpath(__file__))

# default responsivity config file
RESPONSIVITY_FILE = os.path.join(__resources_path, 'responsivity.csv')

# default gain config file
GAIN_CONFIG_FILE = os.path.join(__resources_path, 'gain.csv')


class Responsivity:
    def __init__(self, responsivity_file, wavelength_unit=UNIT_REGISTRY.nm, responsivity_unit=(UNIT_REGISTRY.amp / UNIT_REGISTRY.watt)):
        self.load_csv(responsivity_file, wavelength_unit=wavelength_unit, responsivity_unit=responsivity_unit)
        self.operating_range = self.get_operating_range()

    def __iter__(self):
        for measurement in self.__measurements:
            yield measurement

    def load_csv(self, filename, wavelength_unit=UNIT_REGISTRY.nm, responsivity_unit=(UNIT_REGISTRY.amp / UNIT_REGISTRY.watt)):
        with open(filename,newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            self.__measurements = [(Decimal(row[reader.fieldnames[0]]) * wavelength_unit, Decimal(row[reader.fieldnames[1]]) * responsivity_unit) for row in reader]
    
    def at(self, wavelength):
        """
        Returns the responsivity corresponding to the given wavelength.

        If there is a matching wavelength in the discrete measurements, its corresponding responsivity is returned.
        Otherwise, the measurements which the input wavelength falls between are used to linearly interpolate the approximate responsivity

        Raises ValueError if a wavelength is supplied outside of measurement range.
        """
        
        if not self.is_valid_wavelength(wavelength):
            raise ValueError('Wavelength {0} is not within operating range of device.'.format(str(wavelength)))
        
        # iterate through to find the two measurements the input wavelength falls between
        # if we find an exact match with a measurement, just return its corresponding responsivity
        prev_measurement = None
        current_measurement = None
        for i in range(0,len(self.__measurements)):
            current_measurement = self.__measurements[i]
            if wavelength == current_measurement[0]:
                return current_measurement[1]

            elif wavelength < current_measurement[0]:
                prev_measurement = self.__measurements[i-1]
                break
                
        (wv_low,r_low) = prev_measurement
        (wv_high,r_high) = current_measurement
        
        calc_reponsivity = r_low + (r_high-r_low)/(wv_high-wv_low)*(wavelength - wv_low)
        return calc_reponsivity

    def get_operating_range(self):
        """
        Returns a tuple containing the smallest wavelength and the highest wavelength supported by the device
        """
        return (self.__measurements[0][0], self.__measurements[-1][0])

    def is_valid_wavelength(self, wavelength):
        """
        Returns True if the wavelength supplied is within the range of the responsivity measurements; returns False otherwise
        """
        min_wavelength,max_wavelength = self.operating_range
        return wavelength >= min_wavelength and wavelength <= max_wavelength


class VoltageDAC:
    def __init__(self, min_voltage, max_voltage, adc_precision):
        self.min_voltage = min_voltage
        self.max_voltage = max_voltage
        self.adc_precision = adc_precision

    def to_real_voltage(self, digital_voltage):
        """
        Given an unsigned digital voltage value, uses linear interpolation to convert it to a physical measurement.

        Raises a ValueError if supplied digital_voltage is not unsigned or outside of range allowed by ADC bits
        """
        if (type(digital_voltage) is not int) or (digital_voltage < 0):
            raise TypeError('DAC must be supplied with an unsigned integer literal')
        elif digital_voltage >= (1 << self.adc_precision):
            raise ValueError('Supplied digital voltage 0b{0:b} is not within range for unsigned {1}-bit value'.format(digital_voltage,str(self.adc_precision)))

        return (self.max_voltage - self.min_voltage)/(1 << self.adc_precision) * digital_voltage

class GainConfig:
    def __init__(self,gain_csv, real_gain_unit=(UNIT_REGISTRY.volt / UNIT_REGISTRY.amp), max_voltage_unit=UNIT_REGISTRY.volt):
        self.REAL_GAIN_ATTRIBUTE_NAME = 'real_gain'
        self.MAX_VOLTAGE_ATTRIBUTE_NAME = 'max_voltage'
        self.load_csv(gain_csv, real_gain_unit=real_gain_unit, max_voltage_unit=max_voltage_unit)

    def __iter__(self):
        for setting in self.__gain_settings:
            yield (setting, self.__gain_settings[setting])
    
    def load_csv(self,gain_csv, real_gain_unit=(UNIT_REGISTRY.volt / UNIT_REGISTRY.amp), max_voltage_unit=UNIT_REGISTRY.volt):
        with open(gain_csv,newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            self.__gain_settings = { row[reader.fieldnames[0]]: {self.REAL_GAIN_ATTRIBUTE_NAME: Decimal(row[reader.fieldnames[1]]) * (UNIT_REGISTRY.volt / UNIT_REGISTRY.amp), self.MAX_VOLTAGE_ATTRIBUTE_NAME: Decimal(row[reader.fieldnames[2]]) * UNIT_REGISTRY.volt} for row in reader }

    def __get_setting_attribute(self, gain_setting, attribute):
        gain_setting = str(gain_setting)

        if not gain_setting in self.__gain_settings:
            raise ValueError('Gain setting {0} is not a valid configuration for the device.'.format(gain_setting))
        elif not attribute in self.__gain_settings[gain_setting]:
            raise ValueError('Attribute {0} is not a valid gain setting attribute'.format(str(attribute)))
        
        return self.__gain_settings[gain_setting][attribute]

    def get_real_gain(self, gain_setting):
        return self.__get_setting_attribute(gain_setting,self.REAL_GAIN_ATTRIBUTE_NAME)

    def get_max_voltage(self, gain_setting):
        return self.__get_setting_attribute(gain_setting,self.MAX_VOLTAGE_ATTRIBUTE_NAME)

    def is_valid_setting(self, gain_setting):
        return gain_setting in self.__gain_settings

def device_is_photodetector(port,baudrate=BAUD_RATE):
    """
    Verifies that the device connected to the port is actually the photodetector
    """
    def __send_verify_command(ser):
        ser.write('v'.encode('utf-8'))
    
    try:
        test_connect = serial.Serial(port=port,baudrate=BAUD_RATE,timeout=1)
    except:
        # if the port is already opening, we can't verify if it's a photodetector, so return false
        return False
    time.sleep(1)
    __send_verify_command(test_connect)
    device_response = str(test_connect.readline())
    test_connect.close()
    return DEVICE_ID in device_response

class SampleData:
    def __init__(self):
        self.time = []
        self.intensity = []

    def __iter__(self):
        for sample in list(zip(self.time,self.intensity)):
            yield sample

    def __getitem__(self, key):
        new_samples = SampleData()
        if type(key) is slice:
            new_samples.time = self.time[key]
            new_samples.intensity = self.intensity[key]
        else:
            new_samples.time = [self.time[key]]
            new_samples.intensity = [self.intensity[key]]
        return new_samples

    def add_sample(self, time, intensity):
        self.time.append(time)
        self.intensity.append(intensity)

    def clear_samples(self):
        self.time = []
        self.intensity = []

    def asdict(self):
        return {'time': self.time, 'intensity': self.intensity}


class Photodetector:
    """
    The Photodetector class contains methods related to the operation of discrete photodetector devices.

    The instance methods of the class provide functionality for initiating connections to photodetector devices over Serial.
    A Photodetector can only be instantiated when the physical device is connected over Serial to the host.
    A Photodetector instance can have its input wavelength and gain configured and can be used to control the device's sampling.

    Samples are collected in the current_samples instance variable.  This variable is an instance of the SampleData class
    """

    def __init__(self,port,responsivity_file=RESPONSIVITY_FILE, gain_config_file=GAIN_CONFIG_FILE,baudrate=BAUD_RATE,initial_gain='1',initial_wavelength=None):
        """
        Initialize the photodetector by specifying the port it is connected to
        """
        
        # raise an error if the device cannot be verified as a photodetector
        if not device_is_photodetector(port,baudrate):
            raise RuntimeError("Could not verify device at {0} as a photodetector; instantiation failed.".format(port))

        # initialize responsivity and gain configuration for device
        self.responsivity = Responsivity(responsivity_file)
        self.gain_config = GainConfig(gain_config_file)

        # initialize DAC for device
        self.dac = VoltageDAC(Decimal('0.0')*UNIT_REGISTRY.volt, Decimal('3.3')*UNIT_REGISTRY.volt, 16)

        self.__ser = serial.Serial(port,baudrate)
        
        # sleep for 1 second to allow Arduino to boot when serial connection is established
        # TODO: remove this when we aren't using Arduino anymore
        time.sleep(1)
        
        # __sampling is a private variable used to control execution of the sampling thread
        self.__sampling = False
        
        # __sample_thread is a thread that is used to asynchronously collect samples from the photodetector
        self.__sample_thread = None
        
        # current_samples is shared between threads and holds samples read from the photodetector before returning them
        self.current_samples = SampleData()
        self.latest_sample_time = Decimal('0.0') * UNIT_REGISTRY.sec
        self.latest_sample = None
        
        # set input wavelength
        if initial_wavelength is None:
            initial_wavelength = self.responsivity.operating_range[0]
        self.set_input_wavelength(initial_wavelength)
        
        # set gain
        self.set_gain_setting(initial_gain)

        # set sampling rate
        self.set_sampling_frequency(Decimal(400) / UNIT_REGISTRY.secs)

    # destructor is needed to close the serial port when the object is destroyed
    def __del__(self):
        """Close the serial port that the Photodetector has open once it becomes garbage"""
        self.close()
    
    def close(self):
        if self.__ser.is_open:
            self.__ser.close()
    
    def open(self):
        if not self.__ser.is_open:
            self.__ser.open()
    
    def __sample(self,save_samples=True):
        """
        Polls for data over serial and calculates intensity samples as data is received,
        storing the latest sample in an instance variable for quick access.

        If save_samples is True, each sample will be added to an instance variable
        containing all measured samples.  Otherwise, onlt the most recent sample is saved.
        """
        # __sampling is set to True in another thread when start_sampling is called,
        # and it is set to False in another thread when stop_sampling is called,
        # which tells the thread to stop collecting samples and terminate
        while self.__sampling or self.__ser.in_waiting:
            while self.__ser.in_waiting:
                self.latest_sample = self.__get_intensity_sample()
                if save_samples:
                    self.current_samples.add_sample(self.latest_sample[0], self.latest_sample[1])
            time.sleep(self.sampling_period.to(UNIT_REGISTRY.secs).magnitude)

    def __get_intensity_sample(self):
        """
        Reads a voltage value from the device and calculates its corresponding intensity (in W) given the current
        settings for gain and input wavelength (in nm).
        """
        def __read_voltage_value():
            """
            Read and return a 16-bit voltage sent from the photodetector.
            """
            photovoltage_bytes = self.__ser.read(VOLTAGE_VALUE_BYTES)
            return int.from_bytes(photovoltage_bytes, byteorder='little', signed=False)

        digital_voltage = __read_voltage_value()
        intensity = self.calculate_intensity(digital_voltage,self.gain_setting,self.input_wavelength)
        
        sample = (self.latest_sample_time,intensity)
        self.latest_sample_time += self.sampling_period

        return sample

    def is_sampling(self):
        """
        Returns True if the device is currently sampling, False otherwise.
        """
        return self.__sampling

    def start_sampling(self,asynchronous_collect=True,save_samples=True):
        """
        Sends command to photodetector to begin sampling data from the device.

        If asynchronous_collect is True, a thread is started to collect samples asynchronously.
        If not set, the client must implement their own functionality to read from the device.

        If save_samples is True, all collected samples will be saved in the instance's current_samples member.
        Otherwise, only the most recently collected sample will be retrievable.

        If get_time is True, all samples will have a corresponding time measurement.
        Otherwise, no time measurements will be assigned to the samples.
        """
        def __send_start_sampling_command():
            """Send the command to the photodetector to begin sending photocurrent values"""
            # TODO: update to new protocol once serial is no longer being used
            self.__ser.write('s'.encode('utf-8'))

        def __send_real_time_command():
            """Send the command to the photodetector to sample in real-time, i.e. send samples over serial immediately"""
            self.__ser.write('r'.encode('utf-8'))

        def __send_precision_command():
            """Send the command to the photodetector to sample in precision mode, i.e. leveraging USB bandwidth"""
            self.__ser.write('p'.encode('utf-8'))

        # set real-time sampling mode or precision sampling mode based on asynchronous collect
        # real-time sampling w/ asynchronous collect requires serial data to be sent as soon as available
        # whereas precision sampling can leverage being sent as a packet via USB
        if asynchronous_collect:
            __send_real_time_command()
        else:
            __send_precision_command()

        # issue command to photodetector to start sampling and send values
        __send_start_sampling_command()
        self.__sampling = True
        
        # create the sampling thread to begin sample collection
        if asynchronous_collect:
            self.__sample_thread = threading.Thread(target=self.__sample,args=(save_samples,))
            self.__sample_thread.start()

    def stop_sampling(self):
        """
        Stops the sampling process and terminates any asynchronous sampling processes
        """
        def __send_stop_sampling_command():
            """Send the command to the photodetector to stop sending photocurrent values"""
            self.__ser.write('e'.encode('utf-8'))

        # issue command to photodetector to stop sampling
        __send_stop_sampling_command()
        self.__sampling = False
        
        # tell the sampling thread to stop and wait for it to terminate, if we were collecting asynchronously
        if self.__sample_thread != None:
            self.__sample_thread.join()
            self.__sample_thread = None

        # flush any values left over in the input buffer
        self.__ser.reset_input_buffer()
    
    def clear_samples(self):
        """
        Reset the list of samples and the time at which the first sample is collected
        """
        self.current_samples = SampleData()
        self.latest_sample_time = Decimal('0.0') * UNIT_REGISTRY.sec

    def sample_n_times(self,n_samples):
        """
        Synchronously obtains the next n samples from the device and returns them as a list.  
        Should be used if precision of number of samples is valued over real-time reading of sampled data.
        """
        self.start_sampling(asynchronous_collect=False)
        for i in range(n_samples):
            self.latest_sample = self.__get_intensity_sample()
            self.current_samples.add_sample(self.latest_sample[0], self.latest_sample[1])
        self.stop_sampling()
        return self.current_samples[-n_samples:]

    def set_input_wavelength(self, wavelength):
        """
        Sets the input wavelength for the device.
        Raises an error if the specified wavelength is outside the operating range of the device,
        determined by the range of responsivity measurements.
        """
        if not self.responsivity.is_valid_wavelength(wavelength):
            raise ValueError("Wavelength {0} is outside of the device's operating range.".format(str(wavelength)))
        self.input_wavelength = wavelength

    def set_gain_setting(self, gain_setting):
        """
        Sets the gain for the device.
        Raises an error if the specified gain is not a valid configuration for the device,
        determined by gain measurements.
        """
        if not self.gain_config.is_valid_setting(gain_setting):
            raise ValueError("Gain setting {0} is not a valid setting for the device".format(str(gain_setting)))
        else:
            self.gain_setting = gain_setting
                
    def calculate_intensity(self,voltage,gain_setting,input_wavelength,is_digital_voltage=True):
        """
        Calculates the corresponding intensity (in W) of a digital voltage value given a device gain setting
        and an input wavelength value (in nm).
        """
        if is_digital_voltage:
            voltage = self.dac.to_real_voltage(voltage)
        real_gain = self.gain_config.get_real_gain(gain_setting)
        responsivity = self.responsivity.at(input_wavelength)
        
        return voltage / (real_gain * responsivity)

    def get_max_intensity(self,gain_setting,input_wavelength):
        """
        Calculates the maximum intensity the device can measure at a given gain and input wavelength (in nm)
        """
        return self.calculate_intensity(self.gain_config.get_max_voltage(gain_setting),gain_setting,input_wavelength,is_digital_voltage=False)

    def set_sampling_frequency(self, sampling_frequency):
        """
        Updates the sampling frequency of the device
        """
        def __send_update_frequency_command():
            self.__ser.write('f'.encode('utf-8'))
        
        self.sampling_frequency = sampling_frequency.to(1 / UNIT_REGISTRY.secs)
        self.sampling_period = (Decimal(1) / self.sampling_frequency)
        
        frequency_int = int(self.sampling_frequency.magnitude)
        frequency_bytes = frequency_int.to_bytes(4,byteorder='big',signed=False)

        __send_update_frequency_command()
        self.__ser.write(frequency_bytes)

