import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="youngblood-photodetector",
    version="0.0.3",
    author="Jeffrey Socash",
    author_email="jms570@pitt.edu",
    description="Software library for Youngblood Photonics Lab photodetector",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://pitt-photonics.github.io/",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='~=3.5',
    install_requires=['pint','serial'],
    package_data = {
        'youngblood_photodetector': ['gain.csv','responsivity.csv']
    }
)