The Python code consists of two libraries: `youngblood_photodetector`, which contains code for interfacing with the device over serial, and `data_acquisition`, which contains the code for the prototype data acquisition GUI for the photodetector and provides an example of working with the `youngblood_photodetector` library to produce various apps which interface with the photodetector.

`src` contains the source codes for the `youngblood_photodetector` and `data_acquisition` libraries for refereance and future modification.

`dist` contains the `.tar.gz` and `.whl` archives for the `youngblood_photodetector` and `data_acquisition` libraries for installation of the libraries.

The libraries can be installed from the `.whl` files using the following command:  
`pip install [filename]`

Note that `youngblood_photodetector` should be installed before `data_acquisition` as the latter depends on the former.

Data Acquisition GUI can be run after installing the `data_acquisition` library by executing the command `python -m data_acquisition.index`